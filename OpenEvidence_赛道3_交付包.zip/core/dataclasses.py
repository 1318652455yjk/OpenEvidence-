"""数据契约：Question / Evidence / Claim / Run / Score（与实施规划 §3.1 对齐）"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field, asdict
from typing import Any, Optional


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def _uid(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


@dataclass
class Question:
    id: str
    topic: str                # hypertension | lipids | ...
    difficulty: str           # easy | medium | hard
    question: str
    question_type: str        # mechanism | guideline | latest_trial | insufficient
    freshness: str            # stable | up_to_date
    gold_source_ids: list[str] = field(default_factory=list)
    rubric: dict[str, Any] = field(default_factory=dict)  # 关键回答点 + 扣分项

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Question":
        valid = {k: v for k, v in d.items() if k in cls.__dataclass_fields__}
        return cls(**valid)


@dataclass
class Evidence:
    id: str
    source_type: str          # pubmed | clinicaltrial | guideline | europepmc | wiki
    title: str
    text: str                 # abstract 或 chunk
    authors: str = ""
    published_at: str = ""    # YYYY-MM-DD
    url: str = ""
    pmid: str = ""
    doi: str = ""
    nct_id: str = ""
    guideline_name: str = ""
    page: str = ""
    evidence_level: str = "unknown"  # guideline | systematic_review | rct | cohort | expert | unknown
    population: str = ""
    intervention: str = ""
    comparator: str = ""
    outcome: str = ""
    fetched_at: str = ""
    content_hash: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Evidence":
        valid = {k: v for k, v in d.items() if k in cls.__dataclass_fields__}
        return cls(**valid)


@dataclass
class Claim:
    claim_id: str
    run_id: str
    text: str
    criticality: str = "important"   # critical | important | context
    evidence_ids: list[str] = field(default_factory=list)
    evidence_span_ids: list[str] = field(default_factory=list)
    entailment_score: Optional[float] = None
    population_match: Optional[bool] = None
    time_match: Optional[bool] = None
    conflict_ids: list[str] = field(default_factory=list)
    verification_method: str = ""
    decision: str = "pending"        # supported | unsupported | insufficient | refused

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Run:
    run_id: str = field(default_factory=lambda: _uid("run"))
    question_id: str = ""
    condition: str = ""              # A | B | C | D | E
    model: str = ""
    prompt_version: str = ""
    index_version: str = ""
    retrieved_evidence: list[dict] = field(default_factory=list)
    answer: str = ""
    claims: list[dict] = field(default_factory=list)
    citations: list[str] = field(default_factory=list)
    verification_decision: str = "PASS"   # PASS | WARN | REFUSE
    agent_plan: list[str] = field(default_factory=list)
    tool_trace: list[dict] = field(default_factory=list)
    latency_ms: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    estimated_cost: float = 0.0
    error: str = ""
    created_at: str = field(default_factory=_now)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Run":
        valid = {k: v for k, v in d.items() if k in cls.__dataclass_fields__}
        return cls(**valid)


@dataclass
class Score:
    run_id: str
    question_id: str
    condition: str = ""
    judge_id: str = ""
    # 检索
    hit_at_5: Optional[float] = None
    mrr: Optional[float] = None
    recall_at_50: Optional[float] = None
    rerank_ndcg_8: Optional[float] = None
    # 内容（1-5，LLM judge / 人工）
    relevance: Optional[float] = None
    correctness: Optional[float] = None
    completeness: Optional[float] = None
    faithfulness: Optional[float] = None
    # 引用
    citation_precision: Optional[float] = None
    citation_coverage: Optional[float] = None
    claim_support_rate: Optional[float] = None
    unsupported_claim_rate: Optional[float] = None
    abstention_quality: Optional[float] = None   # 证据不足合理拒答 / 证据充分误拒答
    # 系统
    latency_ms: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    estimated_cost: float = 0.0
    # 审阅
    reviewer: str = ""
    notes: str = ""
    created_at: str = field(default_factory=_now)

    def to_dict(self) -> dict:
        return asdict(self)


def load_jsonl(path: str) -> list[dict]:
    out = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                out.append(json.loads(line))
    return out


def save_jsonl(path: str, records: list[dict], mode: str = "a") -> None:
    import os
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w" if mode == "w" else "a", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
