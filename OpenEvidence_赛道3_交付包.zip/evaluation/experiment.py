"""一键实验运行器：A/B/C/D（可选 E）批量跑题，随机条件顺序 + 全量 JSONL 留痕

用法：
  python -m evaluation.experiment                     # 正式题 12 道 × A/B/C/D
  python -m evaluation.experiment --questions dev8    # 开发题
  python -m evaluation.experiment --conditions A B C D E
  python -m evaluation.experiment --limit 2           # 只跑前 2 道（冒烟测试）
"""
from __future__ import annotations

import argparse
import json
import random
import time
import uuid
from pathlib import Path

from core.config import load_config
from core.dataclasses import Question, Run, load_jsonl, save_jsonl
from core.llm import LLMClient
from evaluation.baseline import run_condition
from retrieval.index import EvidenceStore


def load_questions(path: str, limit: int | None = None) -> list[Question]:
    qs = [Question.from_dict(d) for d in load_jsonl(path)]
    if limit:
        qs = qs[:limit]
    return qs


def run_experiment(cfg, questions: list[Question], conditions: list[str],
                   store: EvidenceStore | None, seed: int = 42,
                   verbose: bool = False, tag: str = "") -> list[Run]:
    llm = LLMClient(cfg["llm"])
    runs: list[Run] = []
    ts = time.strftime("%Y%m%d_%H%M%S")
    runs_path = cfg.path("runs_dir") / f"runs_{tag or ts}.jsonl"

    rng = random.Random(seed)
    for q in questions:
        cond_order = list(conditions)
        rng.shuffle(cond_order)   # 每道题条件顺序随机（公平性要求）
        for cond in cond_order:
            t0 = time.time()
            try:
                run = run_condition(q, cond, cfg, store=store, llm=llm, verbose=verbose)
            except Exception as e:  # 失败不静默丢弃，写入 error
                run = Run(question_id=q.id, condition=cond, model=cfg["llm"]["model"],
                          error=f"{type(e).__name__}: {e}")
            run.latency_ms = int((time.time() - t0) * 1000)
            runs.append(run)
            print(f"[{run.condition}] {q.id} -> {run.verification_decision} "
                  f"({run.latency_ms}ms, err={'Y' if run.error else 'N'})")
            save_jsonl(str(runs_path), [run.to_dict()])

    print(f"\n全部完成: {len(runs)} runs -> {runs_path}")
    return runs


def main() -> None:
    ap = argparse.ArgumentParser(description="赛道3 实验运行器")
    ap.add_argument("--questions", choices=["dev8", "formal12"], default="formal12")
    ap.add_argument("--conditions", nargs="+", default=["A", "B", "C", "D"])
    ap.add_argument("--limit", type=int, default=None, help="只跑前 N 道题（冒烟）")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--no-retrieval", action="store_true", help="只跑 A（无证据库）")
    ap.add_argument("--tag", default="", help="输出文件名标签")
    ap.add_argument("--emb-backend", default=None,
                    help="覆盖 embedding 后端: api|local|fallback")
    args = ap.parse_args()

    cfg = load_config()
    q_path = cfg.path("questions_dev" if args.questions == "dev8" else "questions_formal")
    questions = load_questions(str(q_path), limit=args.limit)

    store = None
    if not args.no_retrieval:
        store = EvidenceStore(cfg)
        store.load().build_index(emb_backend=args.emb_backend)
        print(f"索引版本: {store.index_version}  证据数: {len(store.evidences)}")

    run_experiment(cfg, questions, args.conditions, store=store,
                   seed=args.seed, tag=args.tag)


if __name__ == "__main__":
    main()
