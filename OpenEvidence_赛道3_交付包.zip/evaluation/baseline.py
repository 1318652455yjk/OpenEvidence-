"""run_condition：单个问题 × 单个条件的完整实验流程"""
from __future__ import annotations

from typing import Optional

from core.config import Config
from core.dataclasses import Question, Run
from core.llm import LLMClient
from generation.answer import AnswerGenerator
from retrieval.index import EvidenceStore


def run_condition(q: Question, condition: str, cfg: Config,
                  store: Optional[EvidenceStore] = None,
                  llm: Optional[LLMClient] = None,
                  verbose: bool = False) -> Run:
    """执行一个条件。store 为 None 时视为纯 LLM 条件（A）。

    condition 取值: A | B | C | D | E
    - A: 纯 LLM，无检索
    - B: BM25 + 向量 + RRF 后直接取 top-k
    - C: B + 特征重排 + MMR
    - D: C + Wiki/Agent（当前 MVP 简化为 C + 检索轨迹记录，预留 agent_plan 扩展点）
    - E: 劣化检索（top-k 减半 + 截断，P1 实验用）
    """
    llm = llm or LLMClient(cfg["llm"])
    gen = AnswerGenerator(cfg, llm)
    run = Run(question_id=q.id, condition=condition, model=llm.model,
              prompt_version=cfg["generation"]["prompt_version"])

    if condition == "A":
        run.index_version = "none"
        run.agent_plan = ["condition A: no retrieval"]
        result, _ = gen.generate(q, condition, [], [])
        result.index_version = "none"
        return result

    if store is None:
        raise ValueError(f"条件 {condition} 需要证据库，请先构建 EvidenceStore")

    # ---- 检索 ----
    if condition in ("B", "C", "D"):
        top_evs, features = store.retrieve(
            q.question,
            use_rerank=(condition in ("C", "D")),
            verbose=verbose,
        )
        trace = {"tools": ["bm25", "vector", "rrf"],
                 "rerank": condition in ("C", "D"),
                 "retrieved": len(top_evs)}
        run.tool_trace.append(trace)
        run.index_version = store.index_version
    elif condition == "E":
        # 劣化：只取检索结果的一半，模拟检索质量下降
        top_evs_full, features_full = store.retrieve(
            q.question, use_rerank=True, verbose=verbose)
        n = max(2, len(top_evs_full) // 2)
        top_evs = top_evs_full[:n]
        features = [f for f in features_full if f["doc_id"] in {e["id"] for e in top_evs}]
        run.tool_trace.append({"tools": ["bm25", "vector", "rrf", "degrade"],
                               "retrieved": len(top_evs), "degraded": True})
        run.index_version = store.index_version

    # ---- 生成 + 校验 ----
    result, _ = gen.generate(q, condition, top_evs, features)
    result.index_version = store.index_version
    result.agent_plan = run.agent_plan
    result.tool_trace = run.tool_trace
    return result
