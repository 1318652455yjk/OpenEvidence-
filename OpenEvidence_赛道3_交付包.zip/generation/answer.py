"""答案生成：A/B/C/D 共用安全层（引用白名单 + 拒答判定）"""
from __future__ import annotations

import re
from typing import Optional

from core.config import Config
from core.dataclasses import Question, Run
from core.llm import LLMClient
from generation import prompts
from generation.citation_check import (check_citation_whitelist, find_invalid_urls,
                                       extract_citations)


class AnswerGenerator:
    def __init__(self, cfg: Config, llm: LLMClient):
        self.cfg = cfg
        self.llm = llm
        self.gen_cfg = cfg["generation"]

    def generate(self, q: Question, condition: str,
                 retrieved: list[dict], features: list[dict]) -> tuple[Run, list[dict]]:
        """生成 + 校验，返回 (Run, features)。"""
        run = Run(question_id=q.id, condition=condition,
                  model=self.llm.model,
                  prompt_version=self.gen_cfg["prompt_version"],
                  index_version="",  # 由实验 runner 填充
                  retrieved_evidence=retrieved)

        if condition == "A":
            msgs = prompts.build_prompt_a(q)
        else:
            msgs = prompts.build_prompt_bcd(q, retrieved)

        # 拒答预判：检索质量门（基于 RRF 分而非未归一化的加权分）。
        # A 条件无检索，跳过；真正“证据不足”题的拒答由生成模型处理。
        if condition in ("B", "C", "D") and features:
            best_rrf = max(f.get("rrf", f.get("semantic", 0.0)) for f in features)
            if best_rrf < self.gen_cfg["retrieval_quality_threshold"]:
                run.answer = self._abstain_text(q)
                run.verification_decision = "REFUSE"
                run.agent_plan.append(
                    f"abstain: best_rrf={best_rrf:.4f} < threshold")
                return run, features

        text, meta = self.llm.chat(msgs)
        run.answer = text
        run.latency_ms = meta["latency_ms"]
        run.input_tokens = meta["input_tokens"]
        run.output_tokens = meta["output_tokens"]
        run.estimated_cost = meta["estimated_cost"]

        # ---- 引用白名单校验（B/C/D；A 条件不允许引用） ----
        n_ev = len(retrieved)
        if condition == "A":
            invalid_urls = find_invalid_urls(text)
            if extract_citations(text) or invalid_urls:
                run.verification_decision = "WARN"
                run.error = f"A 条件出现引用或 URL: cites={extract_citations(text)} urls={invalid_urls}"
        else:
            _, invalid = check_citation_whitelist(text, n_ev)
            if invalid:
                run.verification_decision = "WARN"
                run.error = f"非法引用编号(超出本次证据范围): {invalid}"
        run.citations = extract_citations(text)
        return run, features

    def _abstain_text(self, q: Question) -> str:
        return (
            f"## 结论摘要\n本次检索未找到足以回答该问题的可靠证据，因此不做结论。\n\n"
            f"## 局限与边界\n检索缺口可能来自数据范围（高血压/血脂主题库）或证据质量不足。"
            f"如需进一步调研，建议补充指南全文与最新临床试验。\n\n"
            f"（仅供教学研究，不用于临床诊疗）"
        )
